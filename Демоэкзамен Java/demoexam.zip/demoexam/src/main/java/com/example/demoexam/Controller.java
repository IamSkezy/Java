package com.example.demoexam;

//Import libraries
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import static java.util.concurrent.TimeUnit.SECONDS;

public class Controller {
    //Import FXML structures
    @FXML
    TextField loginField;
    @FXML
    TextField codeField;
    @FXML
    TextField passwordHideField;
    @FXML
    PasswordField passwordField;
    @FXML
    CheckBox checkPassword;
    @FXML
    Button resetBtn;
    @FXML
    Button cancelBtn;
    @FXML
    Button enterBtn;
    @FXML
    Label errorEmptyLogin;
    @FXML
    Label errorEmptyPassword;
    @FXML
    Label errorWrongData;
    @FXML
    Label errorWrongCode;

    public String code = "";
    public static String userPost = "";
    public static String userName = "";
    public int countdownStarter = 10;

    public void onPassword(KeyEvent keyEvent) throws SQLException {
        if(keyEvent.getCode() == KeyCode.ENTER) {
            if(loginField.getText().isEmpty()){
                errorEmptyLogin.setVisible(true);
            }
            else {
                String login = loginField.getText();
                DB db = new DB();
                boolean checkLogin = db.validateLogin(login);
                if(!checkLogin) {
                    errorWrongData.setVisible(true);
                }
                else {
                    if(!loginField.getText().isEmpty()){
                        errorEmptyLogin.setVisible(false);
                    }
                    if(checkLogin) {
                        errorWrongData.setVisible(false);
                    }
                    passwordHideField.setDisable(false);
                    passwordField.setDisable(false);
                    checkPassword.setDisable(false);
                }
            }
        }
    }

    //Маска пароля
    public void visiblePass(ActionEvent event){
        if(checkPassword.isSelected()){
            passwordHideField.setText(passwordField.getText());
            passwordHideField.setVisible(true);
            passwordField.setVisible(false);
            return;
        }
        passwordField.setText(passwordField.getText());
        passwordField.setVisible(true);
        passwordHideField.setVisible(false);
    }

    public void onCode(KeyEvent keyEvent) throws SQLException {
        if(keyEvent.getCode() == KeyCode.ENTER) {
            if(passwordField.getText().isEmpty()){
                errorEmptyPassword.setVisible(true);
            }
            else {
                String login = loginField.getText();

                String password = passwordField.getText();

                DB db = new DB();
                boolean checkUser = db.validate(login,password);
                if(!checkUser) {
                    errorWrongData.setVisible(true);
                }
                else{
                    if(!loginField.getText().isEmpty()){
                        errorEmptyLogin.setVisible(false);
                    }
                    if(!passwordField.getText().isEmpty()){
                        errorEmptyPassword.setVisible(false);
                    }
                    if(checkUser) {
                        errorWrongData.setVisible(false);
                    }
                    codeField.setDisable(false);
                    resetBtn.setDisable(false);
                    generateCode();
                }
            }
        }
    }

    public void onProfile(KeyEvent keyEvent) throws SQLException {
        if(keyEvent.getCode() == KeyCode.ENTER) {
            if(codeField.getText().isEmpty()) {
                errorWrongCode.setVisible(true);
            }
            else {
                if(Objects.equals(codeField.getText(), code)) {
                    enterBtn.setDisable(false);
                    resetBtn.setDisable(true);
                }
                else {
                    errorWrongCode.setVisible(true);
                }
            }
        }
    }

    public void generateCode() {
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        int upperbound = chars.length();
        int codeSize = 8;
        code = "";

        for(int i = 0; i < codeSize; i++) {
            Random random = new Random();
            int index = random.nextInt(upperbound);
            code += chars.charAt(index);
        }

        //Output code in terminal
        System.out.println(code);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Generated Code");
        alert.setHeaderText(null);
        alert.setContentText("Your code: " + code);
        alert.showAndWait();

        countdownStarter = 10;
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("Осталось времени:" + countdownStarter);
                countdownStarter--;

                if(Objects.equals(codeField.getText(), code)) {
                    System.out.println("Код верный!");
                    scheduler.shutdown();
                }

                if(countdownStarter == 0) {
                    System.out.println("Вы не успели, обновите код!");
                    code = "";
                    scheduler.shutdown();
                }
            }
        };
        scheduler.scheduleAtFixedRate(runnable,0,1, SECONDS);
    }

    //Clear Data method
    public void clearData(ActionEvent event) {
        loginField.setText("");
        passwordField.setText("");
        codeField.setText("");
        //Hide different errors if they are exists
        errorEmptyLogin.setVisible(false);
        errorEmptyPassword.setVisible(false);
        errorWrongData.setVisible(false);
        errorWrongCode.setVisible(false);
        passwordHideField.setDisable(true);
        checkPassword.setDisable(true);
        passwordField.setDisable(true);
        codeField.setDisable(true);
        enterBtn.setDisable(true);
    }

    public void successAuthorization(ActionEvent event) throws SQLException, IOException {
        String login = loginField.getText();
        String password = passwordField.getText();
        System.out.println("Authorization was successes!\nYour login: " + loginField.getText() + "\nYour password: " + passwordField.getText() + "\nYour code was: " + code + "\nYou write: " + codeField.getText());
        DB db = new DB();
        db.getEmpInfo(login, password);
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("Profile.fxml"));
        File file = new File("src/main/resources/img/logo.png");
        String urlImage = file.toURI().toString();
        stage.getIcons().add(new Image(urlImage));
        stage.setTitle("Охта парк");
        stage.setScene(new Scene(root, 600, 600));
        stage.show();
        stage.setResizable(false);
    }
}
