package com.example.demoexam;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.demoexam.Controller.userPost;
import static com.example.demoexam.Controller.userName;

public class Profile implements Initializable {
    //import FXML data
    @FXML
    Label role;
    @FXML
    Label fio;
    @FXML
    ImageView photo;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        File file = new File("src/main/resources/img/" + userName.split(" ")[0] + ".jpeg");
        Image image = new Image(file.toURI().toString());
        photo.setImage(image);
        fio.setText(userName);
        role.setText(userPost);
    }
}
