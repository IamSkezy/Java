package com.example.demoexam;

//Import libraries
import java.sql.*;
import static com.example.demoexam.Controller.userPost;
import static com.example.demoexam.Controller.userName;

public class DB {
    public static final String DATABASE_URL = "jdbc:mysql://127.0.0.1:3307/demoexam?useSSL=false";
    public static final String DATABASE_USERNAME = "admin";
    public static final String DATABASE_PASSWORD = "12345";
    public static final String SELECT_QUERY = "SELECT * FROM `employees` WHERE login = ? AND password = ?";
    public static final String SELECT_QUERY_LOGIN = "SELECT * FROM `employees` WHERE login = ?";

    //Check data in DB
    public boolean validate(String login, String password) throws SQLException {
        Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY);
        preparedStatement.setString(1, login);
        preparedStatement.setString(2, password);

        //Output for me
        System.out.println(preparedStatement);

        ResultSet resultSet = preparedStatement.executeQuery();

        if(resultSet.next()) {
            connection.close();
            return true;
        }
        else {
            connection.close();
            return false;
        }
    }

    public boolean validateLogin(String login) throws SQLException {
        Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

        PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY_LOGIN);
        preparedStatement.setString(1, login);

        //Output for me
        System.out.println(preparedStatement);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            connection.close();
            return true;
        } else {
            connection.close();
            return false;
        }
    }

    //Метод для получения информации о пользователе
    public  String getEmpInfo(String login, String password) throws SQLException {
        Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
        PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY);
        preparedStatement.setString(1, login);
        preparedStatement.setString(2, password);
        System.out.println(preparedStatement);
        ResultSet resultSet = preparedStatement.executeQuery();
        if((resultSet.next()) && (!resultSet.wasNull())){
            userPost = resultSet.getString(2);
            userName = resultSet.getString(3);
        }
        connection.close();
        return "Failed";
    }
}
